@echo off
rem ============================================================
rem  MEGAHIT for Windows - graphical interface launcher
rem  (keep this file ASCII-only; cmd.exe mis-parses UTF-8 text)
rem ============================================================
setlocal
set "HOME=%~dp0"
set "HOME=%HOME:~0,-1%"

set "PY="
if exist "%HOME%\python\pythonw.exe" set "PY=%HOME%\python\pythonw.exe"
if not defined PY if exist "%HOME%\..\..\python\pythonw.exe" set "PY=%HOME%\..\..\python\pythonw.exe"
if not defined PY for /f "delims=" %%I in ('where pythonw.exe 2^>nul') do if not defined PY set "PY=%%I"
if not defined PY for /f "delims=" %%I in ('where python.exe 2^>nul') do if not defined PY set "PY=%%I"

if not defined PY (
    echo.
    echo   Python not found, cannot start the GUI.
    echo   The command line version still works:  megahit.bat --test
    echo.
    pause
    exit /b 9009
)

start "" "%PY%" "%HOME%\megahit_gui.py"
exit /b 0
