# -*- coding: utf-8 -*-
"""
MEGAHIT for Windows - 图形界面

参考 SPAdes for Windows 的布局：填三个路径 -> 选模式 -> 点 Run assembly -> 看日志。

设计要点
--------
* 只用标准库 tkinter，不引入任何第三方依赖。
* 优先用自带的 `pytk`（同目录下的 tkinter + tcl/tk 运行库）引导，
  这样即便用的是 python.org 的 embeddable 版 Python（本身不带 tkinter）也能跑。
* 直接调用同目录 `bin\\megahit.py`，用当前这个 Python 解释器执行，
  不依赖 PATH 里有没有 python，也不依赖 .bat。
"""

import ctypes
import os
import queue
import re
import shlex
import subprocess
import sys
import threading
import time

HOME = os.path.dirname(os.path.abspath(__file__))

APP_TITLE = "MEGAHIT for Windows"
APP_SUBTITLE = "fast de novo genome assembly - no setup required"

# 界面配色（照着 SPAdes for Windows 的观感）
C_HEADER_BG = "#1b3f66"
C_HEADER_FG = "#ffffff"
C_SUB_FG = "#a9c2dc"
C_BG = "#f0f0f0"
C_BTN_BLUE = "#1f77b4"
C_BTN_BLUE_HOVER = "#2b87c7"
C_LOG_BG = "#121212"
C_LOG_FG = "#d8d8d8"

# 运行模式：显示名 -> 追加到命令行的参数（None 表示“自定义 k 值”）
# 注意：MEGAHIT 1.2.9 只内置 meta-sensitive / meta-large 两个 preset；
#       默认的 meta 模式就是不带 --presets；bulk 用 --min-count 1 加较短的 k 列表。
PRESETS = [
    ("meta - 宏基因组（默认，推荐）", []),
    ("meta-sensitive - 宏基因组·高灵敏（慢）", ["--presets", "meta-sensitive"]),
    ("meta-large - 大型复杂宏基因组（>30 Gbp）", ["--presets", "meta-large"]),
    ("bulk - 单物种/分离株（高覆盖度，快）",
     ["--min-count", "1", "--k-list", "21,29,39,59,79,99"]),
    ("custom - 自定义 k 值", None),
]

_MSG_BOX_TITLE = APP_TITLE


# --------------------------------------------------------------------------
# 启动期：找 tkinter
# --------------------------------------------------------------------------
def _fatal(msg):
    """没有任何界面可用时，用系统 MessageBox 报错（不依赖 tkinter）。"""
    try:
        ctypes.windll.user32.MessageBoxW(None, msg, _MSG_BOX_TITLE, 0x10)
    except Exception:
        sys.stderr.write(msg + "\n")


def _bootstrap_tkinter():
    """尝试导入 tkinter；失败则用同目录 pytk 引导一次。"""
    try:
        import tkinter  # noqa: F401
        return True
    except Exception:
        pass

    candidates = [
        os.path.join(HOME, "pytk"),
        os.path.join(sys.prefix, "pytk"),
        os.path.join(sys.prefix, "tk"),
    ]
    for p in candidates:
        if not os.path.isfile(os.path.join(p, "_tkinter.pyd")):
            continue
        if p not in sys.path:
            sys.path.insert(0, p)
        # 句柄必须保持引用，否则目录会从 DLL 搜索路径里被移除
        try:
            globals()["_dll_dir_handle"] = os.add_dll_directory(p)
        except Exception:
            pass
        tcl = os.path.join(p, "cl", "tcl8.6")
        tk_lib = os.path.join(p, "cl", "tk8.6")
        if os.path.isdir(tcl):
            os.environ.setdefault("TCL_LIBRARY", tcl)
        if os.path.isdir(tk_lib):
            os.environ.setdefault("TK_LIBRARY", tk_lib)
        try:
            import tkinter  # noqa: F401
            return True
        except Exception:
            continue
    return False


if not _bootstrap_tkinter():
    _fatal(
        "无法加载 tkinter，图形界面无法启动。\n\n"
        "请确认 MEGAHIT 目录下存在 pytk 子目录，\n"
        "或者改用自带 tkinter 的 Python 解释器启动本程序。\n\n"
        "命令行版本仍然可用：megahit.bat --test"
    )
    sys.exit(1)

import tkinter as tk  # noqa: E402
from tkinter import filedialog, messagebox, ttk  # noqa: E402


# --------------------------------------------------------------------------
# 小工具
# --------------------------------------------------------------------------
def total_memory_gb():
    """物理内存总量（GB）。"""

    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", ctypes.c_ulong),
            ("dwMemoryLoad", ctypes.c_ulong),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]

    try:
        stat = MEMORYSTATUSEX()
        stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
        ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
        return stat.ullTotalPhys / (1024.0 ** 3)
    except Exception:
        return 8.0


def contig_stats(path):
    """统计 final.contigs.fa：条数、总长、最长、N50。"""
    lengths = []
    with open(path, "r", encoding="utf-8", errors="replace") as fh:
        cur = 0
        for line in fh:
            if line.startswith(">"):
                if cur:
                    lengths.append(cur)
                cur = 0
            else:
                cur += len(line.strip())
        if cur:
            lengths.append(cur)
    if not lengths:
        return 0, 0, 0, 0
    lengths.sort(reverse=True)
    total = sum(lengths)
    half = total / 2.0
    acc = 0
    n50 = 0
    for n in lengths:
        acc += n
        if acc >= half:
            n50 = n
            break
    return len(lengths), total, lengths[0], n50


def human(n):
    for unit in ("bp", "Kb", "Mb", "Gb"):
        if n < 1000 or unit == "Gb":
            return ("%d %s" % (n, unit)) if unit == "bp" else ("%.1f %s" % (n, unit))
        n /= 1000.0
    return str(n)


# --------------------------------------------------------------------------
# 主窗口
# --------------------------------------------------------------------------
class MegahitApp(object):
    def __init__(self, root):
        self.root = root
        self.proc = None
        self.reader = None
        self.queue = queue.Queue()
        self.running = False
        self.started_at = None

        root.title(APP_TITLE)
        root.configure(bg=C_BG)
        root.geometry("1020x980")
        root.minsize(900, 780)
        try:
            root.tk.call("tk", "scaling", ctypes.windll.user32.GetDpiForSystem() / 72.0)
        except Exception:
            pass

        self.var_r1 = tk.StringVar()
        self.var_r2 = tk.StringVar()
        self.var_out = tk.StringVar()
        self.var_mode = tk.StringVar(value=PRESETS[0][0])
        self.var_threads = tk.StringVar(value=str(min(16, os.cpu_count() or 4)))
        self.var_mem = tk.StringVar(value=str(max(1, int(total_memory_gb() * 0.7))))
        self.var_klist = tk.StringVar()
        self.var_minlen = tk.StringVar(value="200")
        self.var_extra = tk.StringVar()
        self.var_status = tk.StringVar(value="Ready.")

        self._build_header()
        body = tk.Frame(root, bg=C_BG)
        body.pack(fill="both", expand=True, padx=14, pady=(12, 12))
        self._build_form(body)
        self._build_buttons(body)
        self._build_log(body)

        self.root.protocol("WM_DELETE_WINDOW", self.on_close)
        self.root.after(100, self._drain_queue)
        self.log("MEGAHIT %s  ·  图形界面已就绪" % self.megahit_version())

    # ---------------- 界面搭建 ----------------
    def _build_header(self):
        head = tk.Frame(self.root, bg=C_HEADER_BG)
        head.pack(fill="x")
        inner = tk.Frame(head, bg=C_HEADER_BG)
        inner.pack(fill="x", padx=16, pady=(10, 10))
        tk.Label(
            inner, text=APP_TITLE, bg=C_HEADER_BG, fg=C_HEADER_FG,
            font=("Microsoft YaHei UI", 16, "bold"), anchor="w",
        ).pack(fill="x")
        tk.Label(
            inner, text=APP_SUBTITLE, bg=C_HEADER_BG, fg=C_SUB_FG,
            font=("Microsoft YaHei UI", 9), anchor="w",
        ).pack(fill="x", pady=(2, 0))
        tk.Frame(self.root, bg="#0e2a47", height=3).pack(fill="x")

    def _row_label(self, parent, text, row):
        tk.Label(
            parent, text=text, bg=C_BG, fg="#333333",
            font=("Microsoft YaHei UI", 10), anchor="w",
        ).grid(row=row, column=0, columnspan=3, sticky="w", pady=(6, 1))

    def _path_row(self, parent, row, var, button_cmd):
        ent = tk.Entry(
            parent, textvariable=var, font=("Consolas", 10),
            relief="solid", bd=1, bg="white",
        )
        ent.grid(row=row, column=0, columnspan=2, sticky="ew", ipady=4, padx=(0, 8))
        tk.Button(
            parent, text="Browse...", command=button_cmd,
            font=("Microsoft YaHei UI", 9), bg="#f7f7f7", relief="solid", bd=1,
            padx=10, pady=3, cursor="hand2",
        ).grid(row=row, column=2, sticky="ew")

    def _build_form(self, parent):
        parent.columnconfigure(0, weight=1)
        parent.columnconfigure(1, weight=1)
        parent.columnconfigure(2, weight=0)

        self._row_label(parent, "Forward reads (R1)", 0)
        self._path_row(parent, 1, self.var_r1, self.pick_r1)

        self._row_label(parent, "Reverse reads (R2)  -  optional for single-end", 2)
        self._path_row(parent, 3, self.var_r2, self.pick_r2)

        self._row_label(parent, "Output folder", 4)
        self._path_row(parent, 5, self.var_out, self.pick_out)

        # 模式 / 线程 / 内存
        opts = tk.Frame(parent, bg=C_BG)
        opts.grid(row=6, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        opts.columnconfigure(0, weight=1)

        tk.Label(opts, text="Assembly mode", bg=C_BG, fg="#333333",
                 font=("Microsoft YaHei UI", 10), anchor="w").grid(row=0, column=0, sticky="w")
        tk.Label(opts, text="Threads", bg=C_BG, fg="#333333",
                 font=("Microsoft YaHei UI", 10), anchor="w").grid(row=0, column=1, sticky="w", padx=(12, 0))
        tk.Label(opts, text="Memory (GB)", bg=C_BG, fg="#333333",
                 font=("Microsoft YaHei UI", 10), anchor="w").grid(row=0, column=2, sticky="w", padx=(12, 0))

        self.cbo_mode = ttk.Combobox(
            opts, textvariable=self.var_mode, values=[p[0] for p in PRESETS],
            state="readonly", font=("Microsoft YaHei UI", 10),
        )
        self.cbo_mode.grid(row=1, column=0, sticky="ew", ipady=3)
        self.cbo_mode.bind("<<ComboboxSelected>>", self._on_mode_change)

        tk.Spinbox(opts, from_=1, to=256, textvariable=self.var_threads,
                   font=("Microsoft YaHei UI", 10), width=6,
                   relief="solid", bd=1).grid(row=1, column=1, sticky="w", padx=(12, 0), ipady=3)
        tk.Spinbox(opts, from_=1, to=2048, textvariable=self.var_mem,
                   font=("Microsoft YaHei UI", 10), width=6,
                   relief="solid", bd=1).grid(row=1, column=2, sticky="w", padx=(12, 0), ipady=3)

        # 高级选项（可折叠）
        self.adv_open = False
        self.adv_frame = tk.Frame(parent, bg=C_BG)
        self.adv_frame.grid(row=8, column=0, columnspan=3, sticky="ew", pady=(8, 0))
        self.adv_frame.columnconfigure(1, weight=1)
        self.adv_frame.columnconfigure(3, weight=1)

        tk.Label(self.adv_frame, text="k 值列表（自定义时用，如 21,29,39）", bg=C_BG,
                 font=("Microsoft YaHei UI", 9), anchor="w").grid(row=0, column=0, sticky="w")
        tk.Entry(self.adv_frame, textvariable=self.var_klist, font=("Consolas", 10),
                 relief="solid", bd=1).grid(row=0, column=1, sticky="ew", padx=(8, 12), ipady=3)
        tk.Label(self.adv_frame, text="最小 contig 长度", bg=C_BG,
                 font=("Microsoft YaHei UI", 9), anchor="w").grid(row=0, column=2, sticky="w")
        tk.Entry(self.adv_frame, textvariable=self.var_minlen, font=("Consolas", 10),
                 width=8, relief="solid", bd=1).grid(row=0, column=3, sticky="w", padx=(8, 0), ipady=3)

        tk.Label(self.adv_frame, text="附加参数（原样传给 megahit.py）", bg=C_BG,
                 font=("Microsoft YaHei UI", 9), anchor="w").grid(row=1, column=0, sticky="w", pady=(6, 0))
        tk.Entry(self.adv_frame, textvariable=self.var_extra, font=("Consolas", 10),
                 relief="solid", bd=1).grid(row=1, column=1, columnspan=3, sticky="ew",
                                            padx=(8, 0), ipady=3, pady=(6, 0))
        self.adv_frame.grid_remove()

        self.btn_adv = tk.Button(
            parent, text="▸ 高级选项", command=self.toggle_adv,
            font=("Microsoft YaHei UI", 9), bg=C_BG, fg="#1f77b4",
            relief="flat", bd=0, cursor="hand2", anchor="w",
        )
        self.btn_adv.grid(row=7, column=0, columnspan=3, sticky="w", pady=(6, 0))

    def _build_buttons(self, parent):
        bar = tk.Frame(parent, bg=C_BG)
        bar.grid(row=9, column=0, columnspan=3, sticky="w", pady=(10, 4))

        self.btn_run = tk.Button(
            bar, text="Run assembly", command=self.on_run,
            font=("Microsoft YaHei UI", 10, "bold"), bg=C_BTN_BLUE, fg="white",
            activebackground=C_BTN_BLUE_HOVER, activeforeground="white",
            relief="flat", bd=0, padx=26, pady=8, cursor="hand2",
        )
        self.btn_run.pack(side="left")

        self.btn_stop = tk.Button(
            bar, text="Stop", command=self.on_stop,
            font=("Microsoft YaHei UI", 10), bg="#f7f7f7", relief="solid", bd=1,
            padx=18, pady=7, cursor="hand2", state="disabled",
        )
        self.btn_stop.pack(side="left", padx=(10, 0))

        tk.Button(
            bar, text="Open output folder", command=self.on_open_out,
            font=("Microsoft YaHei UI", 10), bg="#f7f7f7", relief="solid", bd=1,
            padx=18, pady=7, cursor="hand2",
        ).pack(side="left", padx=(10, 0))

        tk.Label(parent, textvariable=self.var_status, bg=C_BG, fg="#2b6cb0",
                 font=("Microsoft YaHei UI", 10), anchor="w").grid(
            row=10, column=0, columnspan=3, sticky="w", pady=(2, 4))

    def _build_log(self, parent):
        wrap = tk.Frame(parent, bg="#cccccc", bd=0)
        wrap.grid(row=11, column=0, columnspan=3, sticky="nsew", pady=(0, 0))
        parent.rowconfigure(11, weight=1)

        self.txt = tk.Text(
            wrap, bg=C_LOG_BG, fg=C_LOG_FG, insertbackground=C_LOG_FG,
            font=("Consolas", 9), relief="flat", bd=0, wrap="none",
            padx=8, pady=6, height=12, state="disabled",
        )
        sb = tk.Scrollbar(wrap, command=self.txt.yview)
        self.txt.configure(yscrollcommand=sb.set)
        self.txt.pack(side="left", fill="both", expand=True)
        sb.pack(side="right", fill="y")

    # ---------------- 交互 ----------------
    def toggle_adv(self):
        self.adv_open = not self.adv_open
        if self.adv_open:
            self.adv_frame.grid()
            self.btn_adv.configure(text="▾ 高级选项")
        else:
            self.adv_frame.grid_remove()
            self.btn_adv.configure(text="▸ 高级选项")

    def _on_mode_change(self, _evt=None):
        custom = self.preset_value() is None
        if custom and not self.adv_open:
            self.toggle_adv()

    def _ask_file(self, var):
        path = filedialog.askopenfilename(
            title="选择测序 reads 文件",
            filetypes=[
                ("测序文件", "*.fa *.fasta *.fna *.fq *.fastq *.gz *.bz2"),
                ("所有文件", "*.*"),
            ],
        )
        if path:
            var.set(path)
            if var is self.var_r1 and not self.var_out.get().strip():
                self.var_out.set(os.path.join(os.path.dirname(path), "megahit_out"))

    def pick_r1(self):
        self._ask_file(self.var_r1)

    def pick_r2(self):
        self._ask_file(self.var_r2)

    def pick_out(self):
        path = filedialog.askdirectory(title="选择输出目录")
        if path:
            self.var_out.set(path)

    def on_open_out(self):
        out = self.var_out.get().strip()
        if not out:
            messagebox.showinfo(APP_TITLE, "还没有设置输出目录。")
            return
        if not os.path.isdir(out):
            messagebox.showinfo(APP_TITLE, "目录还不存在：\n" + out)
            return
        try:
            os.startfile(out)
        except Exception as exc:
            messagebox.showerror(APP_TITLE, "无法打开目录：%s" % exc)

    def preset_value(self):
        """返回该模式要追加的参数列表；自定义模式返回 None。"""
        name = self.var_mode.get()
        for label, value in PRESETS:
            if label == name:
                return value
        return []

    # ---------------- 日志 ----------------
    def log(self, text, tag=None):
        self.txt.configure(state="normal")
        self.txt.insert("end", text + "\n", tag)
        self.txt.see("end")
        self.txt.configure(state="disabled")

    def _drain_queue(self):
        try:
            while True:
                kind, payload = self.queue.get_nowait()
                if kind == "line":
                    self.log(payload)
                elif kind == "exit":
                    self._on_finished(payload)
        except queue.Empty:
            pass
        self.root.after(120, self._drain_queue)

    # ---------------- 运行 ----------------
    def _validate(self):
        r1 = self.var_r1.get().strip().strip('"')
        r2 = self.var_r2.get().strip().strip('"')
        out = self.var_out.get().strip().strip('"')
        if not r1:
            messagebox.showwarning(APP_TITLE, "请先选择 Forward reads (R1)。")
            return None
        if not os.path.isfile(r1):
            messagebox.showwarning(APP_TITLE, "R1 文件不存在：\n" + r1)
            return None
        if r2 and not os.path.isfile(r2):
            messagebox.showwarning(APP_TITLE, "R2 文件不存在：\n" + r2)
            return None
        if not out:
            messagebox.showwarning(APP_TITLE, "请先选择 Output folder。")
            return None
        try:
            threads = int(self.var_threads.get())
            mem = int(self.var_mem.get())
        except ValueError:
            messagebox.showwarning(APP_TITLE, "Threads 和 Memory 必须是整数。")
            return None
        if threads < 1 or mem < 1:
            messagebox.showwarning(APP_TITLE, "Threads 和 Memory 必须大于 0。")
            return None
        if os.path.isdir(out) and os.listdir(out):
            if not messagebox.askyesno(
                APP_TITLE,
                "输出目录非空：\n%s\n\n要清空该目录后重新运行吗？" % out,
            ):
                return None
            import shutil
            try:
                shutil.rmtree(out)
            except Exception as exc:
                messagebox.showerror(APP_TITLE, "清空目录失败：%s" % exc)
                return None
        return r1, r2, out, threads, mem

    def _build_cmd(self, r1, r2, out, threads, mem):
        py = sys.executable
        script = os.path.join(HOME, "bin", "megahit.py")
        args = [py, script, "-1", r1]
        if r2:
            args += ["-2", r2]
        # megahit.py 的 -m：<1 视为内存占比，>=1 视为字节数，所以这里把 GB 换成字节
        args += ["-o", out, "-t", str(threads), "-m", str(int(mem) * (1024 ** 3))]

        preset = self.preset_value()
        if preset is None:
            klist = self.var_klist.get().strip()
            if klist:
                args += ["--k-list", klist]
        else:
            args += preset

        minlen = self.var_minlen.get().strip()
        if minlen:
            args += ["--min-contig-len", minlen]

        extra = self.var_extra.get().strip()
        if extra:
            try:
                args += shlex.split(extra, posix=False)
            except ValueError:
                args += extra.split()
        return args

    def on_run(self):
        if self.running:
            return
        checked = self._validate()
        if not checked:
            return
        r1, r2, out, threads, mem = checked
        cmd = self._build_cmd(r1, r2, out, threads, mem)

        self.txt.configure(state="normal")
        self.txt.delete("1.0", "end")
        self.txt.configure(state="disabled")

        self.log("$ " + " ".join('"%s"' % a if " " in a else a for a in cmd))
        self.log("")
        self.var_status.set("Running ...")
        self.btn_run.configure(state="disabled", bg="#9bbcd6")
        self.btn_stop.configure(state="normal")
        self.running = True
        self.started_at = time.time()

        env = dict(os.environ)
        env["PYTHONIOENCODING"] = "utf-8"
        try:
            self.proc = subprocess.Popen(
                cmd,
                cwd=HOME,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0,
                env=env,
            )
        except Exception as exc:
            self.log("启动失败：%s" % exc)
            self._on_finished(-1)
            return

        self.reader = threading.Thread(target=self._pump, args=(self.proc,))
        self.reader.daemon = True
        self.reader.start()

    def _pump(self, proc):
        """把子进程输出按行（含 \\r 进度条）塞进队列。"""
        pending = ""
        while True:
            chunk = proc.stdout.read(256)
            if not chunk:
                break
            try:
                pending += chunk.decode("utf-8", "replace")
            except Exception:
                pending += str(chunk)
            parts = re.split(r"[\r\n]", pending)
            pending = parts.pop()
            for line in parts:
                if line.strip():
                    self.queue.put(("line", line.rstrip()))
        if pending.strip():
            self.queue.put(("line", pending.rstrip()))
        code = proc.wait()
        self.queue.put(("exit", code))

    def on_stop(self):
        if not self.proc:
            return
        if not messagebox.askyesno(APP_TITLE, "要中止当前运行吗？"):
            return
        self.var_status.set("Stopping ...")
        try:
            subprocess.run(
                ["taskkill", "/F", "/T", "/PID", str(self.proc.pid)],
                capture_output=True,
            )
        except Exception:
            try:
                self.proc.kill()
            except Exception:
                pass

    def _on_finished(self, code):
        self.running = False
        self.btn_run.configure(state="normal", bg=C_BTN_BLUE)
        self.btn_stop.configure(state="disabled")
        elapsed = 0
        if self.started_at:
            elapsed = time.time() - self.started_at

        out = self.var_out.get().strip().strip('"')
        self.log("")
        if code == 0:
            self.log("=" * 68)
            self.log("完成，用时 %.1f 秒" % elapsed)
            fa = os.path.join(out, "final.contigs.fa")
            if os.path.isfile(fa):
                try:
                    n, total, longest, n50 = contig_stats(fa)
                    self.log("contigs: %d   总长: %s   最长: %s   N50: %s"
                             % (n, human(total), human(longest), human(n50)))
                except Exception as exc:
                    self.log("统计 final.contigs.fa 失败：%s" % exc)
                self.log("结果文件: " + fa)
            else:
                self.log("注意：没有找到 final.contigs.fa")
            self.log("=" * 68)
            self.var_status.set("Done in %.1f s" % elapsed)
        else:
            self.log("=" * 68)
            self.log("运行结束，返回码 %s（非 0 表示失败）" % code)
            self.log("=" * 68)
            self.var_status.set("Failed (exit %s)" % code)
        self.proc = None

    def on_close(self):
        if self.running and self.proc:
            if not messagebox.askyesno(APP_TITLE, "任务还在运行，确定要退出吗？"):
                return
            try:
                subprocess.run(
                    ["taskkill", "/F", "/T", "/PID", str(self.proc.pid)],
                    capture_output=True,
                )
            except Exception:
                pass
        self.root.destroy()

    # ---------------- 版本 ----------------
    def megahit_version(self):
        try:
            out = subprocess.run(
                [sys.executable, os.path.join(HOME, "bin", "megahit.py"), "--version"],
                capture_output=True, timeout=60, cwd=HOME,
            )
            text = out.stdout.decode("utf-8", "replace")
            m = re.search(r"v[\d.]+", text)
            if m:
                return m.group(0)
        except Exception:
            pass
        return "v1.2.9"


def main():
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    MegahitApp(root)
    root.mainloop()


if __name__ == "__main__":
    # 用 pythonw.exe 启动时没有控制台，异常必须弹窗，否则会“静默失败”
    try:
        main()
    except SystemExit:
        raise
    except Exception:
        import traceback

        _fatal("MEGAHIT 图形界面启动失败：\n\n" + traceback.format_exc())
