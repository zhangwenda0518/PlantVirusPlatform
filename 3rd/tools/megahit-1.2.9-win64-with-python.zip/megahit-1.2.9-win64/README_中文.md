# MEGAHIT v1.2.9 for Windows (64-bit, 绿色便携版)

本目录是 [MEGAHIT](https://github.com/voutcn/megahit) v1.2.9 在 Windows 上从源码编译出的**免安装便携版**：
解压即用，不依赖 conda、Visual Studio、MSYS2，也不需要单独安装 Python。

- 上游版本：v1.2.9（commit `c77d45c`）
- 编译器：MinGW-w64 g++ 16.2.0 (UCRT, posix threads, seh)
- 四个可执行文件全部**静态链接**，除 Windows 自带的 UCRT（`api-ms-win-crt-*.dll`）外无任何外部 DLL 依赖
- 内置 Python 3.12.10（embeddable 版），仅用于运行官方的 `megahit` 驱动脚本
- 姊妹版本：`D:\桌面\植物病毒分析平台\3rd\tools\megahit-1.2.9-win64\`（不内置 Python，
  复用平台 `3rd\python`），二进制与本版完全相同，仅 Python 来源不同

## 目录结构

```
megahit-1.2.9-win64\
├─ 启动MEGAHIT图形界面.bat     ← 图形界面入口（双击即可，无控制台窗口）
├─ megahit_gui.py             ← 图形界面主程序（tkinter）
├─ megahit.bat                ← 命令行入口：双击或命令行调用
├─ bin\
│  ├─ megahit.py              ← 官方 Python 驱动（已做 Windows 适配）
│  ├─ megahit_core.exe        ← 运行时自动选择（POPCNT+BMI2）
│  ├─ megahit_core_popcnt.exe
│  ├─ megahit_core_no_hw_accel.exe
│  └─ megahit_toolkit.exe     ← 辅助工具（统计、转换、取子图等）
├─ python\                    ← 内置 Python 3.12.10
├─ pytk\                      ← 图形界面用的 tkinter 运行库（约 7.6 MB）
├─ share\megahit\test_data\   ← 官方自检数据
├─ README_中文.md
└─ 编译与移植说明.md
```

## 图形界面（推荐给不熟悉命令行的使用者）

双击 **`启动MEGAHIT图形界面.bat`**，出现窗口后：

1. `Forward reads (R1)` → Browse 选择 R1（单端数据就只填这一个）；
2. `Reverse reads (R2)` → Browse 选择 R2（单端可留空）；
3. `Output folder` → Browse 选择输出目录（选 R1 后会自动填成同目录下的 `megahit_out`）；
4. `Assembly mode` 选模式，`Threads` 填线程数，`Memory (GB)` 填内存上限；
5. 点 **Run assembly**，下方黑色日志区实时显示进度，结束后自动汇总
   contig 条数、总长、最长序列和 N50。

模式说明：

| 模式 | 实际参数 | 适用 |
| --- | --- | --- |
| meta（默认，推荐） | 不加额外参数 | 常规宏基因组 |
| meta-sensitive | `--presets meta-sensitive` | 想尽量多拼出低丰度物种，慢 |
| meta-large | `--presets meta-large` | 超大型/复杂宏基因组（>30 Gbp） |
| bulk | `--min-count 1 --k-list 21,29,39,59,79,99` | 单物种/分离株，高覆盖度，快 |
| custom | 用「高级选项」里的 `k 值列表` | 自己指定 k 值 |

「高级选项」里还能设置最小 contig 长度和附加参数（原样传给 `megahit.py`）。
运行中可点 **Stop** 中止，**Open output folder** 直接打开结果目录。

> 图形界面只是把同样的命令拼好再调用 `bin\megahit.py`，与命令行版本结果完全一致；
> 命令行更适合批量、脚本化运行。


## 快速验证

打开 **命令提示符 (cmd)**，进入本目录：

```bat
megahit.bat --version
megahit.bat --test
```

`--test` 通过时会输出 `Test passed.`，并在当前目录生成 `megahit_test_out`。

## 常用命令

双端测序（最常用）：

```bat
megahit.bat -1 reads_1.fq.gz -2 reads_2.fq.gz -o result -t 8
```

交错（interleaved）双端：

```bat
megahit.bat --12 interleaved.fq.gz -o result -t 8
```

单端 / 长读长：

```bat
megahit.bat -r reads.fq.gz -o result -t 8
```

多组文库（不同 insert size）可重复 `-1/-2`：

```bat
megahit.bat -1 lib1_1.fq.gz -2 lib1_2.fq.gz -1 lib2_1.fq.gz -2 lib2_2.fq.gz -o result -t 8
```

常用参数：

| 参数 | 说明 |
| --- | --- |
| `-t/--num-cpu-threads` | 线程数，默认用满所有逻辑核 |
| `-m/--memory` | 内存上限，如 `-m 0.8`（占可用内存 80%）或 `-m 32e9` |
| `--min-contig-len` | 输出最短 contig，默认 200 |
| `--k-list` | 自定义 k 值序列，如 `--k-list 21,29,39,59,79,99,119` |
| `--no-mercy` | 不做低覆盖度剔除（灵敏度更高，速度更慢） |
| `--presets` | 只有 `meta-sensitive`（高灵敏）和 `meta-large`（超大）两个；默认 meta 模式不加该参数 |
| `-r` | 单端或长读长输入 |
| `--12` | 交错双端输入 |

完整参数：`megahit.bat -h`

## 输入格式

- FASTA / FASTQ，可直接用 `.fa/.fna/.fq/.fasta/.fastq`
- **gzip (`.gz`) 由核心程序直接读取**，无需先解压
- **bzip2 (`.bz2`) 由内置 Python 先解压**到输出目录的 `tmp\` 下（Windows 无 `mkfifo`，故走临时文件）
- 路径支持中文和空格（已实测），但仍建议输入输出路径尽量用英文，可避免极少数第三方工具的编码问题

## 注意事项

1. **必须用 `megahit.bat` 调用**，不要直接跑 `bin\megahit_core.exe`；`megahit_core` 是底层子命令程序，需按 `megahit_core <subcommand> ...` 使用。
2. 内存：组装人类/复杂宏基因组时占用较高，建议 `-m` 显式限制（例如 `-m 0.8`），否则默认按可用内存自动计算。
3. 中间文件在输出目录的 `tmp\` 中，成功结束后可安全删除；中断后重新运行同一命令会**断点续跑**。
4. 杀毒软件/Windows Defender 首次运行可能扫描 `megahit_core.exe` 造成数秒延迟，属正常现象。
5. 许可证：MEGAHIT 为 GPLv3，本便携包同样遵循 GPLv3，源码见 https://github.com/voutcn/megahit 。

## 引用

Li D, Liu CM, Luo R, Sadakane K, Lam TW. MEGAHIT: an ultra-fast single-node solution for large and complex metagenomics assembly via succinct de Bruijn graph. *Bioinformatics*, 2015, 31(10): 1674-1676.

Li D, Luo R, Liu CM, et al. MEGAHIT v1.0: A fast and scalable metagenome assembler driven by advanced methodologies and community practices. *Methods*, 2016, 102: 3-11.
